# FURYX CLIENT — Minecraft Java 1.21.1 / Fabric

Bu bir **kaynak kod projesidir**, hazır derlenmiş `.jar` değildir. Minecraft 1.21.1, Fabric Loader ve Java 21 hedeflenmiştir.

## Bu sürümde bulunanlar
- Sağ Shift ile açılan kırmızı/siyah Click GUI
- Aç/kapatılabilir FPS + CPS HUD
- Keystrokes (W/A/S/D) göstergesi
- Entity ESP: canlı varlıklarda istemci taraflı parlayan dış çizgi
- Hafif, sürekli çizilen tek HUD paneli

## Henüz bulunmayanlar
- **Freecam** bu sürümde yalnızca menüde planlanan özellik olarak gösterilir; kamera kontrolü uygulanmamıştır.
- Base Finder / blok ESP yoktur.
- CPS sayacı basit bir tuş-basımı sayacıdır; gerçek fare tıklamalarını her durumda kusursuz ölçmez.
- FPS artışı garanti edilemez. Bu mod ağır optimizasyon yapmaz; yalnızca hafif HUD/GUI sunar. Sodium gibi performans modları ayrı değerlendirilmelidir.

## Derleme
1. Bir bilgisayarda JDK 21 ve Gradle uyumlu bir ortam kur.
2. Proje klasöründe `gradle build` çalıştır (Fabric Loom bağımlılıklarını internetten indirir).
3. Çıktı: `build/libs/furyx-client-0.1.0.jar`
4. `.jar` dosyasını Zalith Launcher'ın kullandığı Minecraft 1.21.1 Fabric profilinin `mods` klasörüne kopyala.
5. Aynı profile uyumlu Fabric API kurulu olmalı.

> Not: Android'de yalnızca launcher kullanarak Java mod projesini derlemek kolay değildir. En kolay yol bilgisayarda derleyip `.jar` dosyasını telefona aktarmaktır.

## Tuşlar
- `Right Shift`: Click GUI
- Menüde HUD, Keystrokes ve Entity ESP açılıp kapatılır.

## Güvenli kullanım
ESP'yi kendi dünyanda veya izin verilen sunucularda kullan. Sunucu kuralları, istemci taraflı görsel özellikleri kısıtlayabilir.

## Telefonda bilgisayarsız derleme (GitHub Actions)
Bu projede `.github/workflows/build.yml` iş akışı bulunur. Proje dosyaları bir GitHub deposuna yüklendikten sonra **Actions → Build FURYX CLIENT → Run workflow** ile uzakta derleme başlatılabilir. İşlem başarılı olursa çalışmanın **Artifacts** bölümündeki `FURYX-CLIENT-JAR` paketinden JAR indirilebilir. GitHub arayüzü değişebilir; depo herkese açık değilse ücretsiz kullanım sınırları geçerli olabilir. JAR'ın oluşması, modun oyunda test edildiği anlamına gelmez.
