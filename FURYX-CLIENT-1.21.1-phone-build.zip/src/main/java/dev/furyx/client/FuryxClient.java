package dev.furyx.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class FuryxClient implements ClientModInitializer {
    public static boolean hud = true;
    public static boolean keystrokes = true;
    public static boolean esp = false;
    public static boolean freecam = false; // UI placeholder; freecam camera implementation is not included in v0.1.
    private static KeyBinding openMenu;
    private static boolean wasAttackDown = false;
    private static long lastClickMs = 0;
    private static int cps = 0;
    private static int cpsWindowClicks = 0;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.furyx.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.furyx"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                client.setScreen(new FuryxScreen());
            }

            if (client.player == null || client.world == null) return;

            boolean attackDown = client.options.attackKey.isPressed();
            if (attackDown && !wasAttackDown) {
                cpsWindowClicks++;
                lastClickMs = System.currentTimeMillis();
            }
            wasAttackDown = attackDown;

            long now = System.currentTimeMillis();
            if (now - lastClickMs > 1000) cpsWindowClicks = 0;
            cps = cpsWindowClicks;

            // Client-side glowing outline ESP. Use only in your own/authorized worlds.
            for (Entity entity : client.world.getEntities()) {
                if (entity == client.player) continue;
                if (entity instanceof LivingEntity) {
                    entity.setGlowing(esp);
                }
            }
        });

        HudRenderCallback.EVENT.register((draw, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!hud || client.player == null || client.world == null) return;

            int x = 8, y = 8;
            draw.fill(x - 4, y - 4, x + 126, y + (keystrokes ? 76 : 38), 0xB5101010);
            draw.fill(x - 4, y - 4, x + 126, y - 2, 0xFFFF3030);
            draw.drawText(client.textRenderer, Text.literal("FURYX CLIENT"), x, y, 0xFFFF4040, true);
            draw.drawText(client.textRenderer, Text.literal("FPS: " + client.getCurrentFps()), x, y + 14, 0xFFFFFFFF, true);
            draw.drawText(client.textRenderer, Text.literal("CPS: " + cps), x + 66, y + 14, 0xFFFFFFFF, true);

            if (keystrokes) {
                int ky = y + 31;
                draw.fill(x, ky, x + 24, ky + 20, keyColor(client.options.forwardKey.isPressed()));
                draw.drawCenteredTextWithShadow(client.textRenderer, "W", x + 12, ky + 6, 0xFFFFFFFF);
                draw.fill(x, ky + 22, x + 24, ky + 42, keyColor(client.options.leftKey.isPressed()));
                draw.drawCenteredTextWithShadow(client.textRenderer, "A", x + 12, ky + 28, 0xFFFFFFFF);
                draw.fill(x + 26, ky + 22, x + 50, ky + 42, keyColor(client.options.backKey.isPressed()));
                draw.drawCenteredTextWithShadow(client.textRenderer, "S", x + 38, ky + 28, 0xFFFFFFFF);
                draw.fill(x + 52, ky + 22, x + 76, ky + 42, keyColor(client.options.rightKey.isPressed()));
                draw.drawCenteredTextWithShadow(client.textRenderer, "D", x + 64, ky + 28, 0xFFFFFFFF);
            }
        });
    }

    private static int keyColor(boolean pressed) {
        return pressed ? 0xFFFF3030 : 0xCC292929;
    }
}
