package dev.furyx.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class FuryxScreen extends Screen {
    private static final int RED = 0xFFFF3030;

    public FuryxScreen() {
        super(Text.literal("FURYX CLIENT"));
    }

    @Override
    protected void init() {
        int w = 190;
        int x = (this.width - w) / 2;
        int y = Math.max(28, (this.height - 190) / 2);

        addDrawableChild(ButtonWidget.builder(toggleLabel("HUD", FuryxClient.hud), b -> {
            FuryxClient.hud = !FuryxClient.hud;
            b.setMessage(toggleLabel("HUD", FuryxClient.hud));
        }).dimensions(x, y, w, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleLabel("Keystrokes", FuryxClient.keystrokes), b -> {
            FuryxClient.keystrokes = !FuryxClient.keystrokes;
            b.setMessage(toggleLabel("Keystrokes", FuryxClient.keystrokes));
        }).dimensions(x, y + 25, w, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleLabel("Entity ESP", FuryxClient.esp), b -> {
            FuryxClient.esp = !FuryxClient.esp;
            b.setMessage(toggleLabel("Entity ESP", FuryxClient.esp));
        }).dimensions(x, y + 50, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Freecam: planned"), b -> {
            this.client.player.sendMessage(Text.literal("FURYX: Freecam camera support is not implemented in v0.1 yet."), false);
        }).dimensions(x, y + 75, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, y + 105, w, 20).build());
    }

    private static Text toggleLabel(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = (this.width - 220) / 2;
        int top = Math.max(12, (this.height - 230) / 2);
        context.fill(left, top, left + 220, top + 220, 0xE8101010);
        context.fill(left, top, left + 220, top + 3, RED);
        context.drawCenteredTextWithShadow(textRenderer, "FURYX CLIENT", this.width / 2, top + 10, RED);
        context.drawCenteredTextWithShadow(textRenderer, "Lightweight • Fabric 1.21.1", this.width / 2, top + 23, 0xFFCCCCCC);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
